from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import BookViewSet, borrow_book, return_book, transaction_list

router = DefaultRouter()
router.register('books', BookViewSet)

urlpatterns = router.urls + [
    path('borrow/', borrow_book),
    path('return/<int:borrow_id>/', return_book),
    path('transactions/', transaction_list),
]
