from rest_framework import viewsets, status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Book, BorrowTransaction
from .serializers import BookSerializer, BorrowTransactionSerializer
from django.shortcuts import get_object_or_404

class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

@api_view(['POST'])
def borrow_book(request):
    book = get_object_or_404(Book, id=request.data['book'])
    if book.copies_available < 1:
        return Response({'error': 'No copies available'}, status=400)
    book.copies_available -= 1
    book.save()
    borrow = BorrowTransaction.objects.create(
        user_id=request.data['user'], book=book, status='borrowed'
    )
    return Response(BorrowTransactionSerializer(borrow).data)

@api_view(['POST'])
def return_book(request, borrow_id):
    borrow = get_object_or_404(BorrowTransaction, id=borrow_id)
    if borrow.status == 'returned':
        return Response({'error': 'Book already returned'}, status=400)
    borrow.status = 'returned'
    borrow.return_date = request.data.get('return_date')
    borrow.book.copies_available += 1
    borrow.book.save()
    borrow.save()
    return Response(BorrowTransactionSerializer(borrow).data)

@api_view(['GET'])
def transaction_list(request):
    transactions = BorrowTransaction.objects.all()
    return Response(BorrowTransactionSerializer(transactions, many=True).data)
