<template>
  <div>
    <BookList />
    <BorrowForm />
    <ReturnForm />
    <TransactionTable />
  </div>
</template>

<script>
import BookList from './components/BookList.vue'
import BorrowForm from './components/BorrowForm.vue'
import ReturnForm from './components/ReturnForm.vue'
import TransactionTable from './components/TransactionTable.vue'

export default { components: { BookList, BorrowForm, ReturnForm, TransactionTable } }
</script>
